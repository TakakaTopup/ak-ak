module.exports = {
    multipleStatements  : true,
    host                : 'remotemysql.com',
    user                : 'byMWsNlDww',
    password            : 'PLJiPdPZ32',
    database            : 'byMWsNlDww'
};